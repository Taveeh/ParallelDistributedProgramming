package Model.Runnables;

import Model.Bill;
import Repository.InventoryRepository;

import java.util.List;

public class OperationRunnable implements Runnable {

    private InventoryRepository inventory;
    private List<Bill> billList;

    public OperationRunnable(InventoryRepository inventory, List<Bill> billList) {
        this.inventory = inventory;
        this.billList = billList;
    }

    @Override
    public void run() {
        try {
            billList.forEach(bill -> inventory.processBill(bill));
            // TODO: add random inventory checks

            inventory.checkInventory();
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
