import Repository.MainLockInventoryRepository;
import Repository.InventoryRepository;
import Repository.ProductLockInventoryRepository;
import Service.InventoryService;

public class Main {
    public static void main(String[] args) {
        // InventoryRepository inventory = new MainLockInventoryRepository();
        InventoryRepository inventory = new ProductLockInventoryRepository();

        InventoryService inventoryService = new InventoryService(inventory);

        System.out.println(inventoryService.runOperations(50, 10000, 100000, 12));


        String arch = System.getProperty("os.arch");
        int availableThreads = Runtime.getRuntime().availableProcessors();

        System.out.println("Architecture: " + arch);
        System.out.println("Available threads: " + availableThreads + "\n");
    }
}
